import{ Component } from '@angular/core';
@Component({
    selector:'myapp-root',
    templateUrl:'./CustomerApp.MasterPageView.html'
})
export class MasterPageComponent{
    Title="InventoryApplication";
}