export class HomeModel{
    Homephoto1:string="./assets/img/cust1.jpg";
    Homephoto2:string="./assets/img/cust2.jpg";
    Homephoto3:string="./assets/img/cust3.jpg";
    Homephoto4:string="./assets/img/cust4.png";
}