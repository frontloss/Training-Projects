import { SupplierComponent } from "../Suppliers/CustomerApp.SupplierComponent";
export const SupplierRoutes=[
        {path:'Add',component:SupplierComponent}
];