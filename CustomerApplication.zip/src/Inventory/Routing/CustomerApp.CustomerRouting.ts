import { CustomerComponent } from "../Customer/CustomerApp.CustomerComponent";
export const CustomerRoutes=[
        {path:'Add',component:CustomerComponent}
];